import UserName from "../../user-name"

export default function Page() {
  return <UserName />
}
