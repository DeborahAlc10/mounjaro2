import WeightImpact from "../../weight-impact"

export default function Page() {
  return <WeightImpact />
}
