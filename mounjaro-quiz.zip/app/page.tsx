import Component from "../mounjaro-quiz"

export default function Page() {
  return <Component />
}
