import BodyArea from "../../body-area"

export default function Page() {
  return <BodyArea />
}
