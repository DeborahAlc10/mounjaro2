import BodyType from "../../body-type"

export default function Page() {
  return <BodyType />
}
