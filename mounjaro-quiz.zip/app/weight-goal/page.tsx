import WeightGoal from "../../weight-goal"

export default function Page() {
  return <WeightGoal />
}
