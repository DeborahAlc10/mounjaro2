"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ChevronLeft, Shield, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

// Definindo a cor verde do logo para manter consistência
const logoGreen = "#4CAF50" // Verde do logo Mounjaro do Povo

export default function UserName() {
  const [progress] = useState(90)
  const [name, setName] = useState<string>("")
  const router = useRouter()

  const handleSubmit = () => {
    if (name.trim()) {
      // Armazenar o nome no localStorage para uso em outras páginas
      localStorage.setItem("userName", name.trim())

      // Navegar para a próxima etapa
      setTimeout(() => {
        router.push("/weight-impact")
        console.log(`Nome inserido: ${name}`)
      }, 500)
    }
  }

  const handleReturn = () => {
    router.push("/body-area")
  }

  const isNameValid = name.trim().length > 0

  return (
    <div className="min-h-screen bg-[#F3EDE7] flex flex-col items-center">
      {/* Cabeçalho com Logo */}
      <div className="w-full pt-6 pb-2 px-4 text-center relative">
        {/* Botão de Retorno */}
        <button
          onClick={handleReturn}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-8 h-8 rounded-full bg-white border border-gray-200 shadow-sm"
          aria-label="Voltar para a página anterior"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>

        <img src="/logo-mounjaro-do-povo.png" alt="Mounjaro do Povo" className="h-10 mx-auto" />
      </div>

      {/* Barra de Progresso */}
      <div className="w-full px-4 mb-8 max-w-md">
        <div className="h-2 w-full bg-[#E5E7EB] rounded-full overflow-hidden">
          <div className="h-full" style={{ width: `${progress}%`, backgroundColor: logoGreen }}></div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="w-full max-w-md px-4 pb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          {/* Título */}
          <h2 className="text-xl font-bold mb-6" style={{ fontFamily: "Montserrat, sans-serif", color: "#2D3748" }}>
            Qual seu nome?
          </h2>

          {/* Campo de Input */}
          <div className="mb-6">
            <input
              type="text"
              placeholder="Digite seu nome"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-4 border border-gray-200 rounded-lg text-lg focus:outline-none focus:border-[#4CAF50] transition-colors"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            />
          </div>

          {/* Texto explicativo com ícone de proteção */}
          <div className="flex items-start gap-2 mb-8 text-center justify-center">
            <Shield className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-gray-600 leading-relaxed" style={{ fontFamily: "Montserrat, sans-serif" }}>
              Para montar seu plano personalizado, precisamos do seu nome. Fique tranquila, seus dados estão protegidos
            </p>
          </div>

          {/* Botão Continuar */}
          <Button
            onClick={handleSubmit}
            disabled={!isNameValid}
            className={`w-full py-4 text-lg font-bold flex items-center justify-center gap-2 transition-all duration-200 ${
              isNameValid ? "opacity-100 cursor-pointer" : "opacity-50 cursor-not-allowed"
            }`}
            style={{
              backgroundColor: isNameValid ? logoGreen : "#9CA3AF",
              fontFamily: "Montserrat, sans-serif",
            }}
          >
            Continuar <Check className="w-5 h-5" />
          </Button>

          {/* Seção de Credibilidade */}
          <div className="mt-6 pt-4 border-t border-gray-100">
            {/* Container para os 4 selos lado a lado */}
            <div className="flex items-center justify-center gap-3 mb-4 mx-12">
              <div className="flex items-center justify-center">
                <img src="/terra-logo.png" alt="Terra" className="max-w-full max-h-8 object-contain" />
              </div>
              <div className="flex items-center justify-center">
                <img src="/uol-logo.png" alt="UOL" className="max-w-full max-h-8 object-contain" />
              </div>
              <div className="flex items-center justify-center">
                <img src="/globo-logo.png" alt="Globo" className="max-w-full max-h-8 object-contain" />
              </div>
              <div className="flex items-center justify-center">
                <img src="/estadao-logo.png" alt="Estadão" className="max-w-full max-h-8 object-contain" />
              </div>
            </div>

            <p
              className="text-sm text-center leading-relaxed font-bold text-black"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Mencionada nos maiores sites do Brasil como a alternativa acessível ao Mounjaro tradicional
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
