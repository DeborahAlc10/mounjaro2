"use client"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { AlertTriangle } from "lucide-react"

// Definindo a cor verde do logo para manter consistência
const logoGreen = "#4CAF50" // Verde do logo Mounjaro do Povo

export default function Component() {
  const router = useRouter()

  const handleStartQuiz = () => {
    router.push("/weight-goal")
  }

  return (
    <div className="min-h-screen bg-[#F3EDE7] flex flex-col items-center">
      {/* Cabeçalho com Logo */}
      <div className="w-full pt-6 pb-2 px-4 text-center">
        <img src="/logo-mounjaro-do-povo.png" alt="Mounjaro do Povo" className="h-10 mx-auto" />
      </div>

      {/* Barra de Progresso */}
      <div className="w-full px-4 mb-8 max-w-md">
        <div className="h-2 w-full bg-[#E5E7EB] rounded-full overflow-hidden">
          <div className="h-full" style={{ width: "10%", backgroundColor: logoGreen }}></div>
        </div>
      </div>

      {/* Conteúdo principal */}
      <div className="w-full max-w-md px-4 pb-8">
        {/* Card principal */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          {/* Headline - TEXTO ATUALIZADO */}
          <div className="text-center mb-6">
            <p
              className="text-sm mb-1 font-semibold leading-5"
              style={{
                fontFamily: "Montserrat, sans-serif",
                color: "#2D3748",
              }}
            >
              Tá todo mundo perguntando:
            </p>
            <h1
              className="text-2xl font-extrabold tracking-wide leading-6"
              style={{
                fontFamily: "Montserrat, sans-serif",
                color: logoGreen,
                textShadow: "0px 1px 2px rgba(0,0,0,0.1)",
              }}
            >
              O QUE É ESSE TAL DE MOUNJARO DO POVO?
            </h1>
          </div>

          {/* Subheadline - TEXTO NOVO ADICIONADO */}
          <p className="text-gray-600 mb-6 text-center" style={{ fontFamily: "Montserrat, sans-serif" }}>
            A fórmula popular que seca em 30 dias até 10kg de gordura e custa menos que um delivery.
          </p>

          {/* Imagem central */}
          <div className="flex justify-center my-8">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ChatGPT%20Image%2012_06_2025%2C%2019_37_51-YxTFFDWO9EKhmcrlPppVJyYEGl0ZwX.png"
              alt="Mounjaro do Povo - Receita Natural"
              className="object-contain w-48 h-44"
            />
          </div>

          {/* Micro selo de credibilidade */}
          <div className="flex justify-center mb-6">
            <div className="flex items-center gap-2 px-4 py-2 bg-green-50 rounded-lg">
              {/* Ícone de avatares femininos */}
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-200 rounded-full flex items-center justify-center">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" className="text-green-600">
                    <path
                      d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
                      fill="currentColor"
                    />
                  </svg>
                </div>
                <div className="w-4 h-4 bg-green-300 rounded-full flex items-center justify-center -ml-1">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" className="text-green-700">
                    <path
                      d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
                      fill="currentColor"
                    />
                  </svg>
                </div>
              </div>

              {/* Texto */}
              <span className="text-green-700 text-xs font-normal" style={{ fontFamily: "Inter, sans-serif" }}>
                +28 mil pessoas testaram e aprovaram!
              </span>
            </div>
          </div>

          {/* Caixa de alerta - TEXTO ATUALIZADO (PARCIAL) */}
          <div className="bg-amber-50 border-l-4 border-amber-500 p-4 mb-6 leading-3 leading-4 leading-5">
            <div className="flex">
              <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 flex-shrink-0" />
              <div>
                <p className="text-amber-700 font-medium" style={{ fontFamily: "Montserrat, sans-serif" }}>
                  Essa é sua única chance.
                </p>
                <p className="text-amber-600 text-sm" style={{ fontFamily: "Montserrat, sans-serif" }}>
                  1 acesso por CPF.
                  <br />
                  Se sair da página, perde a vaga.
                </p>
              </div>
            </div>
          </div>

          {/* Botão CTA */}
          <Button
            onClick={handleStartQuiz}
            className="w-full py-6 text-lg font-bold flex items-center justify-center gap-2"
            style={{
              backgroundColor: logoGreen,
              fontFamily: "Montserrat, sans-serif",
            }}
          >
            QUERO A RECEITA →
          </Button>
        </div>
      </div>
    </div>
  )
}
