"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ChevronLeft, Camera, Heart, Frown, Feather } from "lucide-react"

// Definindo a cor verde do logo para manter consistência
const logoGreen = "#4CAF50" // Verde do logo Mounjaro do Povo

export default function WeightImpact() {
  const [progress] = useState(100)
  const [selectedImpact, setSelectedImpact] = useState<string>("")
  const [userName, setUserName] = useState<string>("")
  const router = useRouter()

  useEffect(() => {
    // Recuperar o nome do usuário apenas do localStorage
    // Removendo a dependência de useSearchParams
    if (typeof window !== "undefined") {
      const storedName = localStorage.getItem("userName") || ""
      setUserName(storedName)
    }
  }, [])

  const handleSelection = (impact: string) => {
    setSelectedImpact(impact)
    // Na implementação real, você pode navegar para a próxima etapa ou armazenar a seleção
    setTimeout(() => {
      // router.push("/final-step")
      console.log(`Impacto selecionado: ${impact}`)
    }, 500)
  }

  const handleReturn = () => {
    router.push("/user-name")
  }

  const impactOptions = [
    {
      id: "photos",
      label: "Evito tirar fotos porque tenho vergonha",
      icon: <Camera className="w-6 h-6 text-gray-500" />,
    },
    {
      id: "partner",
      label: "Meu parceiro não me olha mais com desejo como antes",
      icon: <Heart className="w-6 h-6 text-pink-500" />,
    },
    {
      id: "social",
      label: "Evito encontros sociais porque não me sinto bem comigo mesma",
      icon: <Frown className="w-6 h-6 text-amber-500" />,
    },
    {
      id: "none",
      label: "Nenhuma das opções",
      icon: <Feather className="w-6 h-6 text-blue-500" />,
    },
  ]

  return (
    <div className="min-h-screen bg-[#F3EDE7] flex flex-col items-center">
      {/* Cabeçalho com Logo */}
      <div className="w-full pt-6 pb-2 px-4 text-center relative">
        {/* Botão de Retorno */}
        <button
          onClick={handleReturn}
          className="absolute left-4 top-1/2 transform -translate-y-1/2 flex items-center justify-center w-8 h-8 rounded-full bg-white border border-gray-200 shadow-sm"
          aria-label="Voltar para a página anterior"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>

        <img src="/logo-mounjaro-do-povo.png" alt="Mounjaro do Povo" className="h-10 mx-auto" />
      </div>

      {/* Barra de Progresso */}
      <div className="w-full px-4 mb-8 max-w-md">
        <div className="h-2 w-full bg-[#E5E7EB] rounded-full overflow-hidden">
          <div className="h-full" style={{ width: `${progress}%`, backgroundColor: logoGreen }}></div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="w-full max-w-md px-4 pb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          {/* Nome do usuário */}
          <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: "Montserrat, sans-serif", color: "#2D3748" }}>
            {userName.toUpperCase()}
          </h2>

          {/* Título */}
          <h3 className="text-xl font-medium mb-6" style={{ fontFamily: "Montserrat, sans-serif", color: "#2D3748" }}>
            Como o seu peso <span style={{ color: logoGreen }}>impacta sua vida?</span>
          </h3>

          {/* Opções de Impacto */}
          <div className="space-y-3">
            {impactOptions.map((option) => (
              <div
                key={option.id}
                className={`cursor-pointer transition-all duration-200 rounded-lg border p-4 flex items-center gap-4 ${
                  selectedImpact === option.id
                    ? "bg-green-50 border-[#4CAF50]"
                    : "bg-white border-gray-200 hover:border-[#4CAF50]"
                }`}
                onClick={() => handleSelection(option.id)}
              >
                <div className="flex-shrink-0">{option.icon}</div>
                <span
                  className="text-lg"
                  style={{
                    fontFamily: "Montserrat, sans-serif",
                    color: selectedImpact === option.id ? "#2D3748" : "#4A5568",
                  }}
                >
                  {option.label}
                </span>
              </div>
            ))}
          </div>

          {/* Seção de Credibilidade */}
          <div className="mt-6 pt-4 border-t border-gray-100">
            {/* Container para os 4 selos lado a lado */}
            <div className="flex items-center justify-center gap-3 mb-4 mx-12">
              <div className="flex items-center justify-center">
                <img src="/terra-logo.png" alt="Terra" className="max-w-full max-h-8 object-contain" />
              </div>
              <div className="flex items-center justify-center">
                <img src="/uol-logo.png" alt="UOL" className="max-w-full max-h-8 object-contain" />
              </div>
              <div className="flex items-center justify-center">
                <img src="/globo-logo.png" alt="Globo" className="max-w-full max-h-8 object-contain" />
              </div>
              <div className="flex items-center justify-center">
                <img src="/estadao-logo.png" alt="Estadão" className="max-w-full max-h-8 object-contain" />
              </div>
            </div>

            <p
              className="text-sm text-center leading-relaxed font-bold text-black"
              style={{ fontFamily: "Montserrat, sans-serif" }}
            >
              Mencionada nos maiores sites do Brasil como a alternativa acessível ao Mounjaro tradicional
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
